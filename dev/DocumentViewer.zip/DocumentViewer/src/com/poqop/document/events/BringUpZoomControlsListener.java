package com.poqop.document.events;

public interface BringUpZoomControlsListener
{
    public void toggleZoomControls();
}
