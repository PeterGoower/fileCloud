package com.poqop.document.events;

public interface Event<T>
{
    void dispatchOn(Object listener);
}
